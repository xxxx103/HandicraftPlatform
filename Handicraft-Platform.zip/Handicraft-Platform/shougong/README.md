<h1 align="center">《南阳理工二手交易平台 |  Secondary trading platform For Nyist》</h1>

<p align="center">Just For Share | 仅仅分享</p>

<p align="center">
    <img src="https://img-blog.csdnimg.cn/20200508182506766.jpg" alt="网站首页">
</p>

<p align="center"><a href="https://blog.csdn.net/over110522/article/details/83933039">csdn地址</a></p>

# 使用申明
- 禁止用来盈利   
- 前前后后开发2年时间啦 感谢你的支持，麻烦点个star，辛苦

<p align="center">
    将本项目拉取到本地之后，立刻执行是不可以的。首先本地安装redis，然后去[七牛云](https://www.qiniu.com/)注册，
	如果不注册的话，不影响基本的使用，但是如果发布功能和换头像功能使用的话，请先注册七牛云账户获取对应密钥放进项目中config配置文件。
<p>

<p align="center">
	
### 新增关于我们界面 2020/05/06
 <img src="https://img-blog.csdnimg.cn/20200506070138715.png" alt="关于我们">

### 优化界面 2020/05/08
<img src="https://img-blog.csdnimg.cn/20200508182506766.jpg" alt="关于我们">
<img src="https://img-blog.csdnimg.cn/202005101416593.png" alt="关于我们">

### 新增加管理员审核页面 2020/02/26
<img src="https://img-blog.csdnimg.cn/20200226122444724.png" alt="关于我们">

<img src="https://img-blog.csdnimg.cn/20200510142607356.png" alt="关于我们">

### 用户在没有登录的时候点击买东西，会弹出首先登录，同时也可以选择注册
<img src="https://img-blog.csdnimg.cn/20200505154505498.png" alt="关于我们">

### 卖东西的界面使用了可以拖拽的方式让用户上传商品更方便
<img src="https://img-blog.csdnimg.cn/20181110202928861.png" alt="关于我们">

### 用户添加商品到购物车的界面，由于二手商品数量每件比较少，所以限定用户在提交到购物车20分钟内完成结算，否则商品会从购物车内清除
<img src="https://img-blog.csdnimg.cn/20200505154551439.png" alt="关于我们">
<img src="https://img-blog.csdnimg.cn/20181110203102771.gif" alt="加入购物车">

### 加入购物车之后，用户可以去个人中心查看(顺便展示一下更换照片的界面)
<img src="https://img-blog.csdnimg.cn/20200510143211156.png" alt="个人中心">

### 这个时候商品已经在你的购物车内，你在个人中心也可以看到购物车并且去结算
<img src="https://img-blog.csdnimg.cn/20181110203756381.png" alt="结算">

### 去结算
<img src="https://img-blog.csdnimg.cn/20181110203830590.png" alt="关于我们">

### 如果用户没有完成结算的话，会在订单中，同样也有时间限制，每件商品都有根据当初进入订单那个时间算起至三十分钟后自动从订单中取消
<img src="https://img-blog.csdnimg.cn/20181110204036928.png" alt="关于我们">

### 商品列表页面
<img src="https://img-blog.csdnimg.cn/2020050615375933.png" alt="关于我们">

### 在二手商城中难免有些买家觉着卖家定价不合适，会跟商家交谈，所以我也做了一个商品议价的模块，可以实现回复再回复的问题
<img src="https://img-blog.csdnimg.cn/20200505154621528.png" alt="评论">

### 我的总结：

 1. 上面只是简单的页面展示，具体代码在github上，这个项目中有很多的知识点
 2. 希望大家又遇到同样的功能不知道怎么实现的时候，我的代码能够帮到你
 3. 调bug是一件培养心态的一件事，做web也有二年左右了，感觉从代码中培养了好性格

### github地址是:https://github.com/lmx110522/nyist_python_secondmall.git
欢迎访问我的[个人博客](https://lmx110522.github.io/)。
上面的页面可能不太好看，我是一个写后端代码的小码农却喜欢做前台页面，我去努力进步的！，希望你的支持，谢谢花费时间看我的博客，万分感谢！

### 自我介绍
2016级南阳理工软件工程学生
2019-06～2019-12 水滴筹
2019-12~目前 同程旅行

寻找有梦想的你
</p>
