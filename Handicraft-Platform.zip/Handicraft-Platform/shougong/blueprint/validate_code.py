from io import BytesIO
from flask import Blueprint, make_response, session

import random
import string
from PIL import Image, ImageFont, ImageDraw, ImageFilter

validate_code = Blueprint("validate_code", __name__)


def rndColor():
    '''随机颜色'''
    return (random.randint(32, 127), random.randint(32, 127), random.randint(32, 127))


def gene_text():
    '''生成4位验证码'''
    return ''.join(random.sample(string.ascii_letters + string.digits, 4))


def draw_lines(draw, num, width, height):
    '''划线'''
    for _ in range(num):
        x1 = random.randint(0, int(width / 2))
        y1 = random.randint(0, int(height / 2))
        x2 = random.randint(0, width)
        y2 = random.randint(int(height / 2), height)
        draw.line(((x1, y1), (x2, y2)), fill='black', width=1)


def get_verify_code():
    '''生成验证码图形'''
    code = gene_text()
    # 图片大小120×50
    width, height = 120, 50
    # 新图片对象
    im = Image.new('RGB', (width, height), 'white')
    # 字体
    try:
        font = ImageFont.truetype('arial.ttf', 36)
    except:
        # 如果找不到arial.ttf，使用默认字体
        font = ImageFont.load_default()
    # draw对象
    draw = ImageDraw.Draw(im)
    # 绘制字符串
    for item in range(4):
        draw.text((5 + random.randint(-3, 3) + 23 * item, 5 + random.randint(-3, 3)), text=code[item], fill=rndColor(),
                  font=font)
    # 划线
    draw_lines(draw, 2, width, height)
    # 高斯模糊
    im = im.filter(ImageFilter.GaussianBlur(radius=0.5))
    return im, code


@validate_code.route('/code')
def get_code():
    image, code = get_verify_code()
    # 将验证码图片以二进制形式写入在内存中
    buf = BytesIO()
    image.save(buf, 'jpeg')
    buf_str = buf.getvalue()
    # 把二进制作为response发回前端，并设置首部字段
    response = make_response(buf_str)
    response.headers['Content-Type'] = 'image/jpeg'
    # 将验证码字符串储存在session中
    session['image'] = code
    return response
