from flask_mail import Mail, Message

send_mail = Mail()



